<?php 
$con = mysqli_connect('localhost', 'root', '', 'knowing about farming');
?>